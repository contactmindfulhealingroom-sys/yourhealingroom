The Healing Room — Static Blog (No-Build)
=========================================

This folder contains a single-file website you can deploy for free with **Netlify Drop** in under a minute.

Files:
- index.html  (everything is here — Tailwind via CDN, no build step)
- (no Node, no React build, no dependencies)

How to put it online (free, no domain required):
1) Go to https://app.netlify.com/drop
2) Drag-and-drop the *entire folder* (or the ZIP) onto the page.
3) Netlify will instantly give you a free URL like: https://something.netlify.app
4) Share that link anywhere.

How to edit posts:
- In index.html, scroll near the bottom to `const POSTS = [ ... ]` and edit/add your posts.
- You can change cover images (Unsplash links), dates, categories, and tags.
- Text supports new lines in the `content` string.

Optional custom domain later:
- When you're ready, you can add a custom domain in Netlify settings, but it's not required.
